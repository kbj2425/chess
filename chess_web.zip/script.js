const board = document.getElementById("chessboard");
const pieces = {
  r: "♜", n: "♞", b: "♝", q: "♛", k: "♚", p: "♟",
  R: "♖", N: "♘", B: "♗", Q: "♕", K: "♔", P: "♙"
};
let selected = null;

function createBoard() {
  const layout = [
    "rnbqkbnr", "pppppppp", "        ", "        ",
    "        ", "        ", "PPPPPPPP", "RNBQKBNR"
  ];
  board.innerHTML = "";
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const square = document.createElement("div");
      square.className = "square " + ((row + col) % 2 === 0 ? "white" : "black");
      square.dataset.row = row;
      square.dataset.col = col;
      square.textContent = pieces[layout[row][col]] || "";
      square.onclick = () => handleClick(square);
      board.appendChild(square);
    }
  }
}

function handleClick(square) {
  if (selected) {
    selected.style.outline = "";
    if (square !== selected) {
      square.textContent = selected.textContent;
      selected.textContent = "";
    }
    selected = null;
  } else if (square.textContent) {
    selected = square;
    square.style.outline = "2px solid red";
  }
}

createBoard();
